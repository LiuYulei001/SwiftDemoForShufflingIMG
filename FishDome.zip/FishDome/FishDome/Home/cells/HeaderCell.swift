//
//  HeaderCell.swift
//  FishDome
//
//  Created by Rainy on 2016/11/23.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class HeaderCell: UITableViewCell {

    override init(style: UITableViewCellStyle, reuseIdentifier: String?)
    {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = UIColor.black
        setUpUI()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

extension HeaderCell {
    
    
    fileprivate func setUpUI(){
        
        let cycleS = CycleScrollView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 200))

        contentView.addSubview(cycleS)
        
    }
    
    
}
