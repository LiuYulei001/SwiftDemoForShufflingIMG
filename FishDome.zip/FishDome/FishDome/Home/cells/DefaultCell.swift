//
//  DefaultCell.swift
//  FishDome
//
//  Created by Rainy on 2016/11/22.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class DefaultCell: UITableViewCell {

    @IBOutlet weak var IMG: UIImageView!
    
    @IBOutlet weak var title_lab: UILabel!
    
    @IBOutlet weak var new_price: UILabel!
    
    @IBOutlet weak var old_price: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        title_lab.text = "iphone 7 ／ iphone 7 plus"
        new_price.text = "$288"
        old_price.text = "$4999"
        contentView.backgroundColor = UIColor.white
//        IMG.image?.rightSizeImage(image: IMG.image!, Size: IMG.frame.size, completion: { (imaged) in
//            
//            imaged.cornerImageWithSize(size: self.IMG.frame.size, fillColor: self.contentView.backgroundColor!, cornerRadius: 10, completion: { (Img) in
//                
//                self.IMG.image = Img
//            })
//            
//        })
        IMG.layer.masksToBounds = true
        IMG.layer.cornerRadius = 20
        let attb = NSMutableAttributedString(string: old_price.text!)
        
        attb.addAttribute(NSStrikethroughStyleAttributeName, value: NSNumber(value: 2), range: NSMakeRange(0, 5))
        
        old_price.attributedText = attb;
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
