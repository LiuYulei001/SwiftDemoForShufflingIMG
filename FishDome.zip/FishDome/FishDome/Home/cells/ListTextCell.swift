//
//  ListTextCell.swift
//  FishDome
//
//  Created by Rainy on 2016/11/24.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class ListTextCell: UITableViewCell {

    override init(style: UITableViewCellStyle, reuseIdentifier: String?){
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = UIColor.purple
        setUpUI()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
extension ListTextCell{
    
    fileprivate func setUpUI(){
        
        let view = ListTextCellView.init(frame: CGRect.init(x: 0, y: 0, width: kScreenW, height: 40))
        
        contentView.addSubview(view)
        
        
        
    }
    
}
