//
//  ScrollCell.swift
//  FishDome
//
//  Created by Rainy on 2016/11/23.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class ScrollCell: UITableViewCell {
    
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?){
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    

    fileprivate let headerTwo:ScrollCellView = ScrollCellView(frame: CGRect.init(x: 0, y: 0, width: kScreenW, height: kScreenW/2))
}


extension ScrollCell {
    
    
    fileprivate func setUpUI(){
        
        contentView.addSubview(headerTwo)
        
    }
    
    
}
