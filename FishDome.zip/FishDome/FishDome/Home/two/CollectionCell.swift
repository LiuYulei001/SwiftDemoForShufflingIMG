//
//  CollectionCell.swift
//  FishDome
//
//  Created by Rainy on 2016/11/23.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit
import SnapKit

class CollectionCell: UICollectionViewCell {
    
    var indexpath:IndexPath?{
        
        didSet{
            
//            imageView.image?.rightSizeImage(image: imageArray[Int(arc4random() % UInt32(6.0))], Size: imageView.bounds.size, completion: { (image) in
//                
//                self.imageView.image = image
//            })
            imageView.image = imageArray[Int(arc4random() % UInt32(6.0))]
            indexpath?.item += 1
            title_lab.text = "商品展示\(indexpath!.item)"
        }
        
    }
    
    
    
    override init(frame : CGRect){
        
        super.init(frame: frame)
        setUpData()
        setUpUI()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    fileprivate let imageView = UIImageView.init(image: UIImage.init(named: "1"))
    
    fileprivate let title_lab = UILabel()

    fileprivate var imageArray:[UIImage] = []
    
}

extension CollectionCell{
    
    fileprivate func setUpUI(){
        
        title_lab.text = "商品展示"
        title_lab.textAlignment = .center
        title_lab.textColor = UIColor.red
        
        addSubview(title_lab)
        addSubview(imageView)
        
        imageView.backgroundColor = UIColor.yellow
        
        imageView.layer.borderWidth = 1;
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = imageView.bounds.size.width / 2
        imageView.layer.borderColor = UIColor.red.cgColor;
        
        imageView.layer.masksToBounds = false
        imageView.layer.shadowOffset = CGSize(width: 3, height: 3)
        imageView.layer.shadowRadius = 2
        imageView.layer.shadowOpacity = 0.8
        imageView.layer.shadowColor = UIColor.black.cgColor
        
        imageView.snp.makeConstraints { (maker) in
            
            maker.centerX.equalTo(self)
            maker.top.equalTo(self).offset(5)
            
        }
        title_lab.snp.makeConstraints { (maker) in
            
            maker.centerX.equalTo(imageView)
            maker.top.equalTo(imageView.snp.bottom)
        }
        
        
        
    }
    fileprivate func setUpData(){
        
        var arr:[Int] = []
        
        for index in 1...6 {
            
            arr.append(Int(index))
            imageArray.append(UIImage.init(named: "\(index)")!)
        }
        
        
        
        
    }
    
}











