//
//  ScrollCellView.swift
//  FishDome
//
//  Created by Rainy on 2016/11/23.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

let kScreenW = UIScreen.main.bounds.size.width
let kScreenH = UIScreen.main.bounds.size.height


class ScrollCellView: UIView {

    override init(frame:CGRect){
        
        super.init(frame: frame)
        
        setUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate lazy var collectionView: UICollectionView = {
        
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.itemSize = CGSize.init(width: kScreenW / 4, height: self.bounds.size.height/2)
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        
        
        let collectionView = UICollectionView.init(frame: self.bounds, collectionViewLayout: flowLayout)
        
        collectionView.isPagingEnabled = true
        collectionView.backgroundColor = UIColor.white
        collectionView.bounces = true
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.delegate = self
        collectionView.dataSource = self
    
        collectionView.register(CollectionCell.self, forCellWithReuseIdentifier: "CollectionCell")
        
        return collectionView
        
        
    }()
    fileprivate let item_num:Int = 40

    fileprivate lazy var IndicatorView:UIView = {
        
        let IndicatorView:UIView = UIView()
        IndicatorView.alpha = 0
        IndicatorView.backgroundColor = UIColor.blue
        
        
        return IndicatorView
        
    }()
    
}
extension ScrollCellView {
    
    fileprivate func setUpUI(){
        
        addSubview(collectionView)
        addSubview(IndicatorView)
        IndicatorView.snp.makeConstraints { (mark) in
            
            mark.bottom.equalTo(self)
            mark.width.equalTo(kScreenW / (CGFloat(self.item_num) / 8))
            mark.height.equalTo(2)
        }

    }
    
}
extension ScrollCellView: UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return item_num
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath)as! CollectionCell
        
        cell.indexpath = indexPath

        return cell
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        self.IndicatorView.alpha = 1
        
        let page = scrollView.contentOffset.x / kScreenW
        
        UIView.animate(withDuration: 0.3){
            
           self.IndicatorView.frame = CGRect.init(x: page * (self.IndicatorView.frame.size.width), y: self.bounds.size.height - 2, width: self.IndicatorView.frame.size.width, height: self.IndicatorView.frame.size.height)
            
        }
        
        
        
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        UIView.animate(withDuration: 0.3){
            
            self.IndicatorView.alpha = 0
        }
    }
    
}









