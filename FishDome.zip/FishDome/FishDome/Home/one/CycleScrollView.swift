//
//  CycleScrollView.swift
//  FishDome
//
//  Created by Rainy on 2016/11/23.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class CycleScrollView: UIView {

    fileprivate let flowLayout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    fileprivate var collectionView: UICollectionView?
    
    override init(frame : CGRect){
        
        super.init(frame: frame)
        setUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    fileprivate let count = 5
    fileprivate var pageControl:UIPageControl?
    fileprivate var indext = 0
    fileprivate var timer:Timer?
    fileprivate var isScrol:Bool = false
    
    public var imageArray:[String]?
    
    
    @objc fileprivate func cycleTimer()
    {
        
        if indext == count {
            
            collectionView?.scrollToItem(at: IndexPath.init(item: 0, section: 2), at: .centeredHorizontally, animated: true)
            pageControl?.currentPage = 0
            indext = 1
            isScrol = true
            
        }else
        {
            collectionView?.scrollToItem(at: IndexPath.init(item: indext, section: 1), at: .centeredHorizontally, animated: true)
            pageControl?.currentPage = indext
            indext += 1
            
        }
        
        
    }
    
    deinit {
        stopTimer()
    }

}

extension CycleScrollView {
    
    
    fileprivate func setUpUI(){
        
        imageArray = [String]()
        for index in 0..<count {
            
            imageArray?.append("scroll_0\(index + 1)")
            
        }
        
        flowLayout.itemSize = bounds.size
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        
        collectionView = UICollectionView.init(frame: bounds, collectionViewLayout: flowLayout)
        
        guard let collectionView: UICollectionView = collectionView else {
            return
        }
        
        collectionView.isPagingEnabled = true
        collectionView.backgroundColor = UIColor.white
        collectionView.bounces = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.register(CycleViewCell.self, forCellWithReuseIdentifier: "CycleViewCell")
        collectionView.delegate = self
        collectionView.dataSource = self
        addSubview(collectionView)
        
        
        let indexPath = IndexPath.init(item: 0, section: 1)
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
        
        pageControl = UIPageControl.init(frame: CGRect.init(x: (bounds.size.width - 150)/2, y: (bounds.size.height - 40), width: 150, height: 40))
        pageControl?.numberOfPages = count
        pageControl?.currentPage = 0
        pageControl?.currentPageIndicatorTintColor = UIColor.red
        pageControl?.pageIndicatorTintColor = UIColor.darkGray
        addSubview(pageControl!)
        
        startTimer()
        
    }
    fileprivate func startTimer(){
        
        timer = Timer.init(timeInterval: 2, target: self, selector: #selector(self.cycleTimer), userInfo: nil, repeats: true)
        
        let runloop = RunLoop.current
        runloop.add(timer!, forMode: RunLoopMode.commonModes)
        
    }
    fileprivate func stopTimer(){
        
        timer?.invalidate()
    }
    
    
}

extension CycleScrollView: UICollectionViewDelegate,UICollectionViewDataSource{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return count;
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CycleViewCell", for: indexPath)as! CycleViewCell
        cell.imageArray = imageArray
        cell.indexPth = indexPath
        return cell
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        stopTimer()
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        startTimer()
    }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
        if isScrol {
            
            collectionView?.scrollToItem(at: IndexPath.init(item: 0, section: 1), at: .centeredHorizontally, animated: false)
            isScrol = false
        }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        var currentPage = Int(scrollView.contentOffset.x / scrollView.bounds.size.width)
        
        currentPage = Int(currentPage) % (count)
        
        
        pageControl?.currentPage = currentPage
        
        indext =  currentPage
        
        collectionView?.scrollToItem(at: IndexPath.init(item: currentPage, section: 1), at: .centeredHorizontally, animated: false)
        
    }
    
}

























