//
//  CycleViewCell.swift
//  FishDome
//
//  Created by Rainy on 2016/11/23.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class CycleViewCell: UICollectionViewCell {
    
    
    
    
    override init(frame:CGRect)
    {
        super.init(frame: frame)
        setUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    fileprivate var imageView: UIImageView?
    public var imageArray: [String]?
    public var indexPth: IndexPath? {
        
        didSet{
            
            guard let imageArray = imageArray else {
                return
            }
            guard let indexPath = indexPth else {
                return
            }
            
            imageView?.image = UIImage.init(named: "\(imageArray[indexPath.item])")
            imageView?.image?.rightSizeImage(image: (imageView?.image)!, Size: (imageView?.bounds.size)!, completion: { (image) in
                
                self.imageView?.image = image
                
            })
            
        }
    }
    
    
    
}


extension CycleViewCell
{
    fileprivate func setUpUI() {
    
        imageView = UIImageView.init(frame: bounds)
        
        contentView.addSubview(imageView!)
    
    }
}
