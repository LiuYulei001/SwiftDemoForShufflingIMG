//
//  HomeViewController.swift
//  FishDome
//
//  Created by Rainy on 2016/11/22.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

let defaultCellIdentifier:String  = "DefaultCell"


class HomeViewController: RootViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       
        myTableView?.register(ScrollCell.self, forCellReuseIdentifier: "ScrollCell")

        myTableView?.register(HeaderCell.self, forCellReuseIdentifier: "HeaderCell")
        
        myTableView?.register(UINib.init(nibName: defaultCellIdentifier, bundle: nil), forCellReuseIdentifier: defaultCellIdentifier)
        
        myTableView?.register(ListTextCell.self, forCellReuseIdentifier: "ListTextCell")
        
        
        
        
    }

    deinit {
        print("销毁")
    }

}
extension HomeViewController {
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 4
        
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section < 3 {
            return 1
        }
        return 10
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell?
        
        switch indexPath.section {
        case 1:
            
            cell = tableView.dequeueReusableCell(withIdentifier: "HeaderCell", for: indexPath)as! HeaderCell
            
            break
        case 2:
            
            cell = tableView.dequeueReusableCell(withIdentifier: "ScrollCell", for: indexPath)as! ScrollCell

            
            break
        case 0:
            cell = tableView.dequeueReusableCell(withIdentifier: "ListTextCell", for: indexPath)as! ListTextCell
            
            break
            
        default:
            
            cell = tableView.dequeueReusableCell(withIdentifier: defaultCellIdentifier, for: indexPath) as! DefaultCell
        }
        
        
        return cell!
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        
        
        switch indexPath.section {
        case 1:
            return 200
            
        case 2:
            return kScreenW/2
        case 0:
            return 40
            
        default:
        
            return 80
        }
    }
    
}













