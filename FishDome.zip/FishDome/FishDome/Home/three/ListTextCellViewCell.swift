//
//  ListTextCellViewCell.swift
//  FishDome
//
//  Created by Rainy on 2016/11/24.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class ListTextCellViewCell: UICollectionViewCell {
    
    override init(frame: CGRect)
    {
        super.init(frame:frame)
        
        setUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    fileprivate var lable:UILabel?
    var textArray:[String]?
    var indexP:IndexPath?{
        
        didSet{
            
            lable?.text = textArray?[(indexP?.item)!]
        }
    }
    
    
    
}
extension ListTextCellViewCell
{
    fileprivate func setUpUI(){
        
        lable = UILabel.init()
        lable?.backgroundColor = UIColor.randomColor()
        lable?.textColor = UIColor.white
        contentView.addSubview(lable!)
        lable?.textAlignment = .center
        
        lable?.snp.makeConstraints { (make) in
            
            make.width.equalTo(self)
            make.height.equalTo(self)
            make.center.equalTo(self)
        }
        
        
    }
}
