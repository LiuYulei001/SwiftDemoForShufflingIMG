//
//  ListTextCellView.swift
//  FishDome
//
//  Created by Rainy on 2016/11/24.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class ListTextCellView: UIView {
    
    fileprivate let flowLayou:UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    fileprivate var collectionView:UICollectionView?

    
    override init(frame:CGRect){
        
        super.init(frame: frame)
        setUpUI()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    fileprivate var timer:Timer?
    fileprivate var index:Int = 0
    fileprivate var isScroll = false
    
    fileprivate var textArray:[String]?
    
    @objc fileprivate func cycleTimer(){
        
        if index == textArray?.count {
            
            collectionView?.scrollToItem(at: IndexPath.init(item: 0, section: 2), at: .centeredVertically, animated: true)
            index = 1
            isScroll = true
            
        }else
        {
            collectionView?.scrollToItem(at: IndexPath.init(item: index, section: 1), at: .centeredVertically, animated: true)
            index += 1
        }
        
    }
    deinit {
        stopTimer()
    }
    
    
}
extension ListTextCellView{
    
    fileprivate func setUpUI(){
        
        backgroundColor = superview?.backgroundColor
        
        textArray = ["文字滚动测试数据1","文字滚动测试数据2","文字滚动测试数据3","文字滚动测试数据4","文字滚动测试数据5","文字滚动测试数据6"]
        
        flowLayou.itemSize = bounds.size
        flowLayou.scrollDirection = .vertical
        flowLayou.minimumLineSpacing = 0
        flowLayou.minimumInteritemSpacing = 0
        
        collectionView = UICollectionView.init(frame: bounds, collectionViewLayout: flowLayou)
        
        guard let collectionView = collectionView else {
            return
        }
        collectionView.isPagingEnabled = true
        collectionView.backgroundColor = superview?.backgroundColor
        collectionView.bounces = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.register(ListTextCellViewCell.self, forCellWithReuseIdentifier: "ListTextCellViewCell")
        addSubview(collectionView)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        let indexP = IndexPath.init(item: 0, section: 1)
        collectionView.scrollToItem(at: indexP, at: .centeredVertically, animated: false)
        startTimer()
        
        
    }
    fileprivate func startTimer(){
        
        timer = Timer.init(timeInterval: 1, target: self, selector: #selector(self.cycleTimer), userInfo: nil, repeats: true)
        let runLoop = RunLoop.current
        runLoop.add(timer!, forMode: RunLoopMode.commonModes)
        
    }
    fileprivate func stopTimer(){
        
        timer?.invalidate()
    }
}


extension ListTextCellView:UICollectionViewDelegate,UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return (textArray?.count)!
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ListTextCellViewCell", for: indexPath)as! ListTextCellViewCell
        cell.textArray = textArray
        cell.indexP = indexPath
        return cell
    }
    
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        stopTimer()
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        startTimer()
    }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
        if isScroll {
            
            collectionView?.scrollToItem(at: IndexPath.init(item: 0, section: 1), at: .centeredVertically, animated: false)
            isScroll = false
        }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        var currentpage = Int(scrollView.contentOffset.y / scrollView.bounds.size.height)
        
        currentpage = currentpage % (textArray?.count)!
        
        index = currentpage
        
        collectionView?.scrollToItem(at: IndexPath.init(item: index, section: 1), at: .centeredVertically, animated: false)
    }
}

















