//
//  MainViewController.swift
//  FishDome
//
//  Created by Rainy on 2016/11/22.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        //计算字符串长度和字节数
        let str:String = "你的法撒3你法9尼"
        print(str.characters.count)
        print(str.lengthOfBytes(using: .utf8))
        // Do any additional setup after loading the view.
        setUpUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension MainViewController{
    
  
    fileprivate func setUpUI() {
        
        addChildViewController(tittle: "首页", vc: HomeViewController(), imageName: "tabbar_home")

        addChildViewController(tittle: "发现", vc: DisCoverViewController(), imageName: "tabbar_discover")
        addChildViewController(tittle: "设置", vc: SetViewController(), imageName: "tabbar_discover")
    }
    fileprivate func addChildViewController(tittle:String, vc: UIViewController ,imageName: String) {
        
        vc.title = tittle
        vc.tabBarItem.image = UIImage(named: imageName)
        vc.tabBarItem.selectedImage = UIImage(named:(imageName + "_selected"))?.withRenderingMode(.alwaysOriginal)
        let naVC = UINavigationController(rootViewController: vc)
        vc.tabBarItem.setTitleTextAttributes([NSForegroundColorAttributeName:UIColor.orange], for: .selected)
        self.addChildViewController(naVC)
        
        
    }
    
    
}
