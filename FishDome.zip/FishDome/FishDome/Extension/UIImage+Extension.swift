//
//  UIImage+Extension.swift
//  FishDome
//
//  Created by Rainy on 2016/11/22.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

extension UIImage {
    
    /// 异步生成圆角图像
    ///
    /// - parameter size:         图片size
    /// - parameter fillColor:    填充颜色
    /// - parameter cornerRadius: 圆角
    /// - parameter completion:   回调
    func cornerImageWithSize(size:CGSize,fillColor:UIColor,cornerRadius:CGFloat,completion:@escaping (_ img:UIImage)->()){
        
        DispatchQueue.global().async {
            
            UIGraphicsBeginImageContextWithOptions(size, true, UIScreen.main.scale)
            //填充颜色
            fillColor.setFill()
            let rect = CGRect(x: 0, y: 0, width: size.width, height: size.height)
            UIRectFill(rect)
            
            let path = UIBezierPath(roundedRect: rect, cornerRadius: cornerRadius)
            
            path.addClip()
            
            self.draw(in: rect)
            
            let result = UIGraphicsGetImageFromCurrentImageContext()
            
            UIGraphicsEndImageContext()
            
            DispatchQueue.main.async {
                guard let image = result else{
                    return
                }
                completion(image)
            }
            
        }
        
        
    }

    /// 异步裁剪图片
    ///
    /// - parameter image:       要裁剪的图片
    /// - parameter Size:       裁剪siz
    /// - parameter completion: 完成回调
    func rightSizeImage(image:UIImage,Size:CGSize,completion:@escaping (_ img:UIImage)->()){
        
        DispatchQueue.global().async {
            UIGraphicsBeginImageContextWithOptions(Size, true, UIScreen.main.scale)
            
            //填充颜色
            let color = UIColor.white
            color.setFill()
            let rect = CGRect(x: 0, y: 0, width:Size.width, height: Size.height)
            UIRectFill(rect)
            
            image.draw(in: rect)
            
            let result = UIGraphicsGetImageFromCurrentImageContext()
            
            UIGraphicsEndImageContext()
            
            DispatchQueue.main.async {
                guard let image = result else{
                    return
                }
                
                completion(image)
            }
            
        }
        
    }

    
}
