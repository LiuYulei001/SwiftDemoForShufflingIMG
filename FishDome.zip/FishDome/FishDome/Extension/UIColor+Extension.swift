//
//  UIColor+Extension.swift
//  FishDome
//
//  Created by Rainy on 2016/11/24.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import Foundation

import UIKit

extension UIColor {
    
    
    public class func colorWithHex(hex:UInt32)->UIColor{
        
        let r = (hex & 0xFF0000)>>16
        let g = (hex & 0x00FF00)>>8
        let b = (hex & 0x0000FF)
    
        return color(r: r, g: g, b: b)
    }
    private class func color(r:UInt32,g:UInt32,b:UInt32)->UIColor{
        
        return UIColor.init(colorLiteralRed: Float(r)/255.0, green: Float(g)/255.0, blue: Float(b)/255.0, alpha: 1)
        
    }
    
    
    
    public class func colorWithRGBA(r:Float,g:Float,b:Float,a:Float)->UIColor{
        
        return UIColor.init(colorLiteralRed: Float(r)/255.0, green: Float(g)/255.0, blue: Float(b)/255.0, alpha: a)
        
    }
    
    
    public class func randomColor()->UIColor{
        
       return color(r: arc4random() % UInt32(256.0), g: arc4random() % UInt32(256.0), b: arc4random() % UInt32(256.0))
        
    }
    
    
    
    
    
    
    
    
    
}
