//
//  RootViewController.swift
//  FishDome
//
//  Created by Rainy on 2016/11/22.
//  Copyright © 2016年 Rainy. All rights reserved.
//

import UIKit

class RootViewController: UIViewController {

    
    var finished : ((_ str:String)->())?
    
    var myTableView:UITableView?
    
    deinit {
        print("对象销毁")
    }
    
    override func loadView() {
        
        setUpUI()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        
        // Do any additional setup after loading the view.
    }


}
extension RootViewController {
    
    fileprivate func setUpUI() {
        
        myTableView = UITableView(frame:CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height) , style : .plain)
        view = myTableView
        myTableView?.backgroundColor = UIColor.white
        myTableView?.delegate = self
        myTableView?.dataSource = self
        
        
    }
    
}



extension RootViewController: UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 0
    }
}








